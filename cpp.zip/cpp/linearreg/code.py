import csv

def read_csv(filename):
    x1 = []
    x2 = []
    with open(filename, 'r') as file:
        csvreader = csv.reader(file)
        next(csvreader)
        for row in csvreader:
            if len(row) == 2:  
                x1.append(float(row[0]))
                x2.append(float(row[1]))
    return x1, x2

def linear_regression(x1, x2):
    n = len(x1)
    sum_x1 = sum(x1)
    print("sum of x1 variable",sum_x1)

    sum_x2 = sum(x2)
    print("sum of x2 variable",round(sum_x2,2))


    sum_x1_x2 = sum(xi * yi for xi, yi in zip(x1, x2))
  
    print("sum of multiplication of x1*x2",round(sum_x1_x2,2))

    sum_x1_squared = sum(xi ** 2 for xi in x1)

    print("sum of squares of numbers",round(sum_x1_squared,2))

    b1 = (n * sum_x1_x2 - sum_x1 * sum_x2) / (n * sum_x1_squared - sum_x1 ** 2)

    b0 = round((sum_x2 - b1 * sum_x1) / n,2)
    return b0, b1

def predict(x1, b0, b1):
    return [round(b0 + b1 * xi,2) for xi in x1]

def main():
    x1, x2 = read_csv(r"C:/Users/Omkar/OneDrive/Desktop/DM/linearreg/data.csv")
    b0, b1 = linear_regression(x1, x2)
    print(f"Intercept (b0): {b0}")
    print(f"Slope (b1): {b1}")
    y_pred = predict(x1, b0, b1)
    print(f"Predicted values: {y_pred}")

if __name__ == "__main__":
    main()
