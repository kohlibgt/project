import csv
from collections import defaultdict


# Load transactions with binary data (1s and 0s for each item)
def load_transactions(filename):
    try:
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            data = [row for row in reader]
        header = data[0]  # First row as header
        transactions = [
            set(index for index, value in enumerate(row) if int(value) == 1) for row in data[1:]
        ]
        return header, transactions
    except FileNotFoundError:
        print(f"Error: The file {filename} was not found.")
        return None, None
    except ValueError:
        print("Error: The transactions file should contain binary values (1 or 0) only.")
        return None, None

# Load association rules from file
def load_rules(filename):
    rules = []
    try:
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            next(reader)  # Skip header
            for row in reader:
                item1 = row[0].split(", ")
                item2 = row[1].split(", ")
                confidence = float(row[2])
                rules.append((set(item1), set(item2), confidence))
        return rules
    except FileNotFoundError:
        print(f"Error: The file {filename} was not found.")
        return None
    except ValueError:
        print("Error: Please ensure the confidence values in rules file are numbers.")
        return None

# Calculate support and confidence for each rule in the transaction dataset
def calculate_support_confidence(transactions, rules):
    total_transactions = len(transactions)
    item_support_count = defaultdict(int)
    rule_results = []

    # Count support for individual items and item pairs
    for transaction in transactions:
        for item in transaction:
            item_support_count[frozenset([item])] += 1
        for antecedent, consequent, _ in rules:
            itemset = antecedent.union(consequent)
            if itemset.issubset(transaction):
                item_support_count[frozenset(itemset)] += 1

    # Calculate support and confidence for each rule
    for antecedent, consequent, conf in rules:
        rule_set = antecedent.union(consequent)
        antecedent_support = item_support_count[frozenset(antecedent)]
        rule_support = item_support_count[frozenset(rule_set)]

        support = rule_support / total_transactions
        confidence = rule_support / antecedent_support if antecedent_support > 0 else 0

        rule_results.append((antecedent, consequent, support, confidence))

    return rule_results

def main():
    # Load transactions
    transactions_file = 'C:/Users/Omkar/OneDrive/Desktop/DM/new_association/new.csv'

    header, transactions = load_transactions(transactions_file)
    
    if transactions is None:
        return  # Stop if there's an error loading transactions

    # Load association rules
    rules_file = 'new.csv'
    rules = load_rules(rules_file)
    
    if rules is None:
        return  # Stop if there's an error loading rules

    # Calculate support and confidence for each rule
    rule_results = calculate_support_confidence(transactions, rules)
    
    # Output results
    for antecedent, consequent, support, confidence in rule_results:
        print(f"Rule: {', '.join(header[i] for i in antecedent)} -> {', '.join(header[i] for i in consequent)}")
        print(f"Support: {support}")
        print(f"Confidence: {confidence}")
        print("-" * 30)

if __name__ == "__main__":
    main()
