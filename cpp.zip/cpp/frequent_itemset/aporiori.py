import csv
from itertools import combinations

def get_itemsets(transactions, length):
    itemsets = set()
    for transaction in transactions:
        for itemset in combinations(sorted(transaction), length):
            itemsets.add(itemset)
    return itemsets

def get_frequent_itemsets(transactions, min_support, n):
    itemsets = []
    level = 1
    candidate_itemsets = get_itemsets(transactions, level)

    while candidate_itemsets:
        itemset_count = {}
        for itemset in candidate_itemsets:
            itemset_count[itemset] = 0

        for transaction in transactions:
            for itemset in candidate_itemsets:
                if set(itemset).issubset(transaction):
                    itemset_count[itemset] += 1

        frequent_itemsets = {}
        for itemset, count in itemset_count.items():
            if count >= min_support:
                frequent_itemsets[itemset] = count

        if not frequent_itemsets:
            print("no frequent itemset found for level", level)
            break

        print(f"\nFrequent itemsets (level {level}):")
        for item, count in frequent_itemsets.items():
            print(f"Itemset: {item}, Support: {count/len(transactions) * 100:.2f}%")

        itemsets.append(frequent_itemsets)
        candidate_itemsets = set()
        frequent_items = set()

        for sublist in itemsets[-1].keys():
            for item in sublist:
                frequent_items.add(item)

        level += 1
        for itemset in combinations(frequent_items, level):
            candidate_itemsets.add(itemset)

    return itemsets

def read_csv_transactions(file_path):
    transactions = []
    with open(file_path, 'r', encoding='utf-8-sig') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            transaction = set(item.strip() for item in row if item)
            transactions.append(transaction)
    return transactions

def main():
    file_path =  'C:/Users/Omkar/OneDrive/Desktop/DM/frequent_itemset/transactions.csv' 

    transactions = read_csv_transactions(file_path)
    n = len(transactions)
    support_percentage = float(input("Enter the minimum support as a percentage (e.g., 50 for 50%): "))
    min_support = (support_percentage / 100) * n
    get_frequent_itemsets(transactions, min_support, n)

if __name__ == "__main__":
    main()
