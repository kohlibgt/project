import csv

def read_csv(file_name):
    data = []
    with open(file_name, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            data.append(row)
    return data

def mean(values):
    return sum(values) / len(values)

def pearson_correlation(x, y):
    n = len(x)
    mean_x = mean(x)
    mean_y = mean(y)
    
    numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    denominator_x = sum((x[i] - mean_x) ** 2 for i in range(n))
    denominator_y = sum((y[i] - mean_y) ** 2 for i in range(n))
    
    denominator = (denominator_x * denominator_y) ** 0.5
    if denominator == 0:
        return 0
    return numerator / denominator

def correlation_strength(coefficient):
    if 0.7 <= abs(coefficient) <= 1.0:
        return "Strong"
    elif 0.3 <= abs(coefficient) < 0.7:
        return "Moderate"
    else:
        return "Weak"

# Main program
file_name = 'C:/Users/Omkar/OneDrive/Desktop/DM/newcorrelation/input.csv'  # Update with the correct path if needed
data = read_csv(file_name)

# Extract 'ise' and 'ese' marks
ise = [float(row['ise']) for row in data]
ese = [float(row['ese']) for row in data]

# Calculate correlation
correlation = pearson_correlation(ise, ese)
strength = correlation_strength(correlation)

print(f"Pearson Correlation Coefficient between ISE and ESE: {correlation}")
print(f"Correlation Strength: {strength}")
