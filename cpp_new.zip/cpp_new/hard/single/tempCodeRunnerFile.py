for row in distMat:
            print(row)